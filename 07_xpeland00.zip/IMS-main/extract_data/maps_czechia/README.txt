This is where the dataset of maps is kept. The data is too large to submit with the project.

It can be dowloaded from https://download.geofabrik.de/europe/czech-republic.html# in raw directory index

The files I have locally are:
    - 140101.osm.pbf
    - 150101.osm.pbf
    - 160101.osm.pbf
    - 170101.osm.pbf
    - 180101.osm.pbf
    - 190101.osm.pbf
    - 200101.osm.pbf
    - 210101.osm.pbf
    - 220101.osm.pbf
    - 230101.osm.pbf
    - 240101.osm.pbf
    - 250101.osm.pbf
    - 250901.osm.pbf
    - README.md
