echo "[SCRIPT]: Starting"
python3 residential.py
echo "[SCRIPT]: Residential generated"

# python3 protected.py
# echo "[SCRIPT]: Protected generated"

# python3 forest.py
# echo "[SCRIPT]: Forest generated"

python3 roads.py
echo "[SCRIPT]: Roads generated"

# python3 slope_extract.py
# echo "[SCRIPT]: Height extracted from map"

# python3 slope.py
# echo "[SCRIPT]: Slope generated"

echo "[SCRIPT]: Finished"
